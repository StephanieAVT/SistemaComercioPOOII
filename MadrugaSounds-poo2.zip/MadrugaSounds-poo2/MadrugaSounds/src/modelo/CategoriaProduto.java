package modelo;

public class CategoriaProduto {
    int idCategoriaProduto;
    String categoriaNomeProduto;
     public int getidCategoriaProduto() {
        return idCategoriaProduto;
    }
    public void setidCategoriaProduto(int idCategoriaProduto) {
        this.idCategoriaProduto = idCategoriaProduto;
    }
     public String getcategoriaNomeProduto() {
        return categoriaNomeProduto;
    }
    public void setcategoriaNomeProduto(String categoriaNomeProduto) {
        this.categoriaNomeProduto = categoriaNomeProduto;
    }
}